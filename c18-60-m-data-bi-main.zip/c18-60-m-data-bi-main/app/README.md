## App Prject

Para usar el contenedor de esta app desde la terminal:

1) Con git clone clonar el repositorio
2) Tener descargado Docker
3) cd folder_app
4) Docker build -t nombre_image:v1.0
5) docker run -p puertos_disponibles nombre_image